# ReelBlock

Blocks the Instagram Reels player while leaving DMs, feed, stories, profiles, search, likes and comments usable.

## Build (Android Studio)
1. Install Android Studio (Koala or newer, bundled JDK 17).
2. File > Open > select the `ReelBlock` folder. Let Gradle sync (Studio fetches dependencies and the Gradle wrapper).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
   Output: `app/build/outputs/apk/debug/app-debug.apk`
   CLI alternative: run `gradle wrapper` once, then `./gradlew assembleDebug`.
4. Install: `adb install app/build/outputs/apk/debug/app-debug.apk`, or copy the APK to your phone.

## First run
1. Open ReelBlock, read and accept the consent screen.
2. Tap "Enable in Accessibility settings" > ReelBlock > turn on.
   (Android 13+: if greyed out, App info > ⋮ > "Allow restricted settings", then retry.)
3. Open Instagram and try the Reels tab, a Reel in a DM, or a reel link.

## How it works
`ReelBlockService` (AccessibilityService, limited to com.instagram.android / .lite) checks for Instagram's
Reels view IDs or a selected Reels tab. On detection it taps Home (tab case) or presses Back, then
increments an encrypted counter. If Instagram renames those IDs, update `VIEWER_IDS` in ReelBlockService.kt.
