package com.reelblock.app

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Purple = Color(0xFF8B5CF6)
private val Blue = Color(0xFF3B82F6)
private val CardBg = Color(0xFF121218)
private val Muted = Color(0xFF9A9AB0)
private val Good = Color(0xFF34D399)
private val Bad = Color(0xFFF87171)
private val Grad = Brush.linearGradient(listOf(Purple, Blue))

@Composable
fun ReelBlockApp(onOpenAccessibility: () -> Unit) {
    val ctx = LocalContext.current
    val s by ReelBlockStore.state.collectAsState()
    var settings by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Color.Black, surface = CardBg)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding().padding(20.dp)) {
                if (!s.consent) Onboarding { ReelBlockStore.setConsent(ctx, true) }
                else Crossfade(settings, label = "nav") { inSettings ->
                    if (inSettings) SettingsScreen(s, onBack = { settings = false }, onAccess = onOpenAccessibility)
                    else Dashboard(s, onSettings = { settings = true }, onAccess = onOpenAccessibility)
                }
            }
        }
    }
}

@Composable
private fun Onboarding(onAccept: () -> Unit) {
    var checked by remember { mutableStateOf(false) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Spacer(Modifier.height(24.dp))
        Text("ReelBlock", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Use Instagram without Reels.", color = Muted, fontSize = 16.sp)
        InfoCard {
            Text("Why we need Accessibility access", fontWeight = FontWeight.SemiBold, color = Color.White)
            Spacer(Modifier.height(8.dp))
            Text(
                "• ReelBlock uses Android's Accessibility Service only while the Instagram app is on screen.\n" +
                "• It looks at interface element names (like the Reels player) to know when Reels is open, then goes back / returns to Home.\n" +
                "• It never reads your messages, posts, passwords or any personal content.\n" +
                "• It has no internet permission. Nothing leaves your phone. The only data kept is a block counter, stored encrypted.\n" +
                "• You can switch it off anytime in Android Settings.", color = Muted, lineHeight = 21.sp)
        }
        Row(Modifier.clip(RoundedCornerShape(12.dp)).clickable { checked = !checked }.padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked, { checked = it })
            Text("I understand and consent", color = Color.White)
        }
        GradButton("Continue", enabled = checked, onClick = onAccept)
    }
}

@Composable
private fun Dashboard(s: UiState, onSettings: () -> Unit, onAccess: () -> Unit) {
    val ctx = LocalContext.current
    val active = s.enabled && s.serviceOn
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ReelBlock", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.weight(1f))
            IconButton(onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
        }
        val bg by animateColorAsState(if (active) Purple.copy(alpha = .25f) else CardBg, tween(500), label = "bg")
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(bg).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(if (active) Icons.Default.Shield else Icons.Default.Warning, null, tint = if (active) Color.White else Muted, modifier = Modifier.size(56.dp))
            Spacer(Modifier.height(8.dp))
            Text(if (active) "Reels are blocked" else if (!s.serviceOn) "Setup needed" else "Protection paused", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            Spacer(Modifier.height(12.dp))
            Switch(checked = s.enabled, onCheckedChange = { ReelBlockStore.setEnabled(ctx, it) },
                colors = SwitchDefaults.colors(checkedTrackColor = Purple))
            Text(if (s.enabled) "ReelBlock ON" else "ReelBlock OFF", color = Muted, fontSize = 13.sp)
        }
        InfoCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(RoundedCornerShape(50)).background(if (s.serviceOn) Good else Bad))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Instagram blocking", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(if (s.serviceOn) "Accessibility service running" else "Accessibility access is off", color = Muted, fontSize = 13.sp)
                }
            }
            if (!s.serviceOn) {
                Spacer(Modifier.height(12.dp)); GradButton("Enable in Accessibility settings", onClick = onAccess)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Total blocked", s.total, Modifier.weight(1f))
            Stat("Today", s.today, Modifier.weight(1f))
        }
        InfoCard {
            Text("Last 7 days", color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            val max = (s.week.maxOfOrNull { it.count } ?: 0).coerceAtLeast(1)
            Row(Modifier.fillMaxWidth().height(120.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                s.week.forEach { d ->
                    val h by animateFloatAsState(d.count.toFloat() / max, tween(700), label = "bar")
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom, modifier = Modifier.fillMaxHeight()) {
                        Text("${d.count}", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(4.dp))
                        Box(Modifier.width(26.dp).height((70 * h).dp.coerceAtLeast(4.dp)).clip(RoundedCornerShape(8.dp)).background(Grad))
                        Spacer(Modifier.height(4.dp))
                        Text(d.label, color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
        Text("DMs, feed, stories, profiles, search, likes and comments keep working normally.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SettingsScreen(s: UiState, onBack: () -> Unit, onAccess: () -> Unit) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Text("Settings", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
        InfoCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Show \"Reel blocked\" message", color = Color.White)
                    Text("Small toast each time a Reel is stopped", color = Muted, fontSize = 12.sp)
                }
                Switch(s.toasts, { ReelBlockStore.setToasts(ctx, it) }, colors = SwitchDefaults.colors(checkedTrackColor = Purple))
            }
        }
        InfoCard { Column(Modifier.clickable(onClick = onAccess)) {
            Text("Accessibility settings", color = Color.White); Text("Turn the ReelBlock service on or off", color = Muted, fontSize = 12.sp) } }
        InfoCard { Column(Modifier.clickable { confirm = true }) {
            Text("Reset statistics", color = Bad); Text("Clears counters on this device", color = Muted, fontSize = 12.sp) } }
        InfoCard { Text("Privacy: no internet permission, no accounts, no analytics. ReelBlock only inspects Instagram's screen structure to detect Reels.", color = Muted, fontSize = 12.sp) }
    }
    if (confirm) AlertDialog(onDismissRequest = { confirm = false },
        confirmButton = { TextButton({ ReelBlockStore.resetStats(ctx); confirm = false }) { Text("Reset") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } },
        title = { Text("Reset statistics?") })
}

@Composable
private fun Stat(label: String, value: Int, modifier: Modifier) {
    val v by animateIntAsState(value, tween(700), label = "count")
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(CardBg).padding(20.dp)) {
        Text("$v", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(label, color = Muted, fontSize = 13.sp)
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(CardBg).padding(20.dp).animateContentSize(), content = content)
}

@Composable
private fun GradButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
        .background(if (enabled) Grad else Brush.linearGradient(listOf(Color(0xFF2A2A35), Color(0xFF2A2A35))))
        .clickable(enabled = enabled, onClick = onClick).padding(16.dp), contentAlignment = Alignment.Center) {
        Text(text, color = if (enabled) Color.White else Muted, fontWeight = FontWeight.SemiBold)
    }
}
