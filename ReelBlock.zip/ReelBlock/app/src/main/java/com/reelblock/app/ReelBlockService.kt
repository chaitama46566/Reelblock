package com.reelblock.app

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Watches ONLY Instagram windows (see accessibility_service_config.xml), looks only at
 * view-ID names / selected state (never text, messages or user content), and leaves the
 * Reels player when it is detected. Nothing is stored except a block counter.
 */
class ReelBlockService : AccessibilityService() {

    private var lastBlockAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        ReelBlockStore.init(applicationContext)
        ReelBlockStore.refresh(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            val e = event ?: return
            if (e.packageName?.toString() !in IG_PACKAGES) return
            if (!ReelBlockStore.state.value.enabled) return
            if (System.currentTimeMillis() - lastBlockAt < DEBOUNCE_MS) return
            val root = rootInActiveWindow ?: return
            if (root.packageName?.toString() !in IG_PACKAGES) return
            if (isReelsScreen(root)) leaveReels(root)
        } catch (t: Throwable) {
            Log.w(TAG, "scan failed", t) // never crash the service
        }
    }

    private fun byId(root: AccessibilityNodeInfo, id: String): List<AccessibilityNodeInfo> =
        root.findAccessibilityNodeInfosByViewId("$ID_PREFIX$id") ?: emptyList()

    /** Full-screen Reels player (tab, shared link from DM/browser, or reached by scrolling/tapping a reel). */
    private fun isReelsScreen(root: AccessibilityNodeInfo): Boolean {
        if (byId(root, "clips_tab").any { it.isSelected }) return true
        return VIEWER_IDS.any { id -> byId(root, id).any { it.isVisibleToUser } }
    }

    private fun leaveReels(root: AccessibilityNodeInfo) {
        lastBlockAt = System.currentTimeMillis()
        val reelsTabSelected = byId(root, "clips_tab").any { it.isSelected }
        var done = false
        if (reelsTabSelected) {
            // Jump to Home feed tab so Instagram stays open
            done = byId(root, "feed_tab").firstNotNullOfOrNull { clickable(it) }
                ?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
        }
        // Opened from DM / profile / link / feed: Back returns to where the user came from
        if (!done) performGlobalAction(GLOBAL_ACTION_BACK)

        ReelBlockStore.recordBlock(applicationContext)
        if (ReelBlockStore.state.value.toasts)
            Toast.makeText(applicationContext, "Reel blocked by ReelBlock", Toast.LENGTH_SHORT).show()
    }

    private fun clickable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var cur = n; var depth = 0
        while (cur != null && depth < 5) { if (cur.isClickable) return cur; cur = cur.parent; depth++ }
        return null
    }

    override fun onInterrupt() {}

    companion object {
        private const val TAG = "ReelBlock"
        private const val DEBOUNCE_MS = 900L
        private const val ID_PREFIX = "com.instagram.android:id/"
        private val IG_PACKAGES = setOf("com.instagram.android", "com.instagram.lite")
        // Instagram view IDs of the full-screen Reels player. IDs can change between
        // Instagram releases - add new ones here if blocking stops working.
        private val VIEWER_IDS = listOf(
            "clips_viewer_view_pager", "clips_viewer_container", "clips_swipe_refresh_container",
            "clips_viewer_clips_tab_fragment_container", "clips_video_container"
        )
    }
}
