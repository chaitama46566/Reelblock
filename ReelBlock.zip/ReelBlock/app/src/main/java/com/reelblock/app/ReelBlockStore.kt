package com.reelblock.app

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.*

data class DayCount(val label: String, val count: Int)

data class UiState(
    val enabled: Boolean = true,
    val consent: Boolean = false,
    val toasts: Boolean = true,
    val serviceOn: Boolean = false,
    val total: Int = 0,
    val today: Int = 0,
    val week: List<DayCount> = emptyList(),
)

/** Encrypted local storage; shared between the UI and the accessibility service (same process). */
object ReelBlockStore {
    private var prefs: SharedPreferences? = null
    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state

    @Synchronized
    fun init(ctx: Context) {
        if (prefs != null) return
        val app = ctx.applicationContext
        prefs = try {
            val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                app, "reelblock_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (t: Throwable) { // keystore problems: fall back to private prefs (no sensitive data stored)
            app.getSharedPreferences("reelblock_fallback", Context.MODE_PRIVATE)
        }
        publish(app)
    }

    private fun dayKey(offset: Int = 0): String {
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -offset) }
        return "d_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
    }

    private fun publish(ctx: Context) {
        val p = prefs ?: return
        val labels = SimpleDateFormat("EEE", Locale.getDefault())
        val week = (6 downTo 0).map { off ->
            val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -off) }
            DayCount(labels.format(c.time).take(3), p.getInt(dayKey(off), 0))
        }
        _state.value = UiState(
            enabled = p.getBoolean("enabled", true),
            consent = p.getBoolean("consent", false),
            toasts = p.getBoolean("toasts", true),
            serviceOn = isServiceEnabled(ctx),
            total = p.getInt("total", 0),
            today = p.getInt(dayKey(0), 0),
            week = week,
        )
    }

    fun refresh(ctx: Context) = publish(ctx.applicationContext)
    fun setEnabled(ctx: Context, v: Boolean) { prefs?.edit()?.putBoolean("enabled", v)?.apply(); publish(ctx) }
    fun setConsent(ctx: Context, v: Boolean) { prefs?.edit()?.putBoolean("consent", v)?.apply(); publish(ctx) }
    fun setToasts(ctx: Context, v: Boolean) { prefs?.edit()?.putBoolean("toasts", v)?.apply(); publish(ctx) }

    fun recordBlock(ctx: Context) {
        val p = prefs ?: return
        p.edit().putInt("total", p.getInt("total", 0) + 1)
            .putInt(dayKey(0), p.getInt(dayKey(0), 0) + 1).apply()
        publish(ctx)
    }

    fun resetStats(ctx: Context) {
        val p = prefs ?: return
        val e = p.edit().putInt("total", 0)
        p.all.keys.filter { it.startsWith("d_") }.forEach { e.remove(it) }
        e.apply(); publish(ctx)
    }

    fun isServiceEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(ctx, ReelBlockService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }
}
